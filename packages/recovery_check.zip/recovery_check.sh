#!/bin/sh

FLAG=/boot/recover-base
STORE=/home/solex/recovery/files

fail() {
    echo $1
    exit 1
}

do_recovery() {
    echo $0: `whoami` running recovery process on `uname -n` on `date`

    cd $STORE || fail "Unable to cd to $STORE"

    cp -v ./etc/network/interfaces /etc/network/interfaces || fail "Failed to copy /etc/network/interfaces"
    cp -v ./etc/dnsmasq.conf /etc/dnsmasq.conf || fail "Unable to copy /etc/dnsmasq.conf"
    cp -v ./etc/hostapd/hostapd.conf /etc/hostapd/hostapd.conf || fail "Unable to copy /etc/hostapd/hostapd.conf"

    rm $FLAG
    /sbin/reboot
}

ls $FLAG && do_recovery

