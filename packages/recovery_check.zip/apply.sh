#!/bin/sh

cp -v recovery_check.sh /home/solex/recovery


