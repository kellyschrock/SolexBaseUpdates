#!/bin/sh

unzip -o solexbase-bin.zip /home/webapp/build || exit 127




