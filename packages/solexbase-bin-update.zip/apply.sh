#!/bin/sh

unzip -o solexbase-bin.zip -d /home/webapp/build || exit 127




