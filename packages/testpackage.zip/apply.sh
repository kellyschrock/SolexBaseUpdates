#!/bin/sh

echo Hello, the current working directory is `pwd`.

exit 0


